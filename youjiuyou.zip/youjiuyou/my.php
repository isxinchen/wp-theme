<?php
/*
Template Name: my
*/
?>